<?php
class User {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // تسجيل الدخول
    public function login($username, $password) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        return false;
    }

    // إضافة مستخدم جديد
    public function addUser($username, $password, $full_name, $role_level, $parent_id) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->pdo->prepare("INSERT INTO users (username, password, full_name, role_level, parent_id) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$username, $hashedPassword, $full_name, $role_level, $parent_id]);
    }

    // جلب المستخدمين التابعين لمستخدم معين
    public function getSubordinates($parent_id, $is_admin = false) {
        if ($is_admin) {
            $stmt = $this->pdo->prepare("SELECT id, username, full_name, role_level, parent_id FROM users WHERE id != ? ORDER BY role_level ASC");
            $stmt->execute([$parent_id]);
        } else {
            $stmt = $this->pdo->prepare("SELECT id, username, full_name, role_level, parent_id FROM users WHERE parent_id = ? ORDER BY role_level ASC");
            $stmt->execute([$parent_id]);
        }
        return $stmt->fetchAll();
    }

    // جلب بيانات مستخدم معين
    public function getUserById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    // تحديث بيانات مستخدم
    public function updateUser($id, $username, $full_name) {
        $stmt = $this->pdo->prepare("UPDATE users SET username = ?, full_name = ? WHERE id = ?");
        return $stmt->execute([$username, $full_name, $id]);
    }

    // إعادة تعيين كلمة المرور
    public function resetPassword($id, $new_password) {
        $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $this->pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        return $stmt->execute([$hashedPassword, $id]);
    }

    // حذف مستخدم
    public function deleteUser($id) {
        // التحقق من عدم وجود تابعين قبل الحذف أو التعامل معهم
        $stmt = $this->pdo->prepare("DELETE FROM users WHERE id = ?");
        return $stmt->execute([$id]);
    }

    // التحقق من الصلاحيات
    public function hasAccess($user_role, $required_role) {
        return $user_role <= $required_role;
    }

    /**
     * التحقق مما إذا كان المستخدم target_id يتبع للمستخدم manager_id بشكل هرمي
     * @param int $target_id معرف المستخدم المراد فحص تبعيته
     * @param int $manager_id معرف المدير المحتمل
     * @return bool true إذا كان target_id يتبع manager_id، false وإلا
     */
    public function isSubordinate($target_id, $manager_id) {
        $current = $target_id;
        while ($current != null) {
            if ($current == $manager_id) return true;
            $stmt = $this->pdo->prepare("SELECT parent_id FROM users WHERE id = ?");
            $stmt->execute([$current]);
            $row = $stmt->fetch();
            if (!$row) break;
            $current = $row['parent_id'];
        }
        return false;
    }
}
?>