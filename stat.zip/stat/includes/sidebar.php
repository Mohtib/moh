<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/db.php';

$role_level = (int)$_SESSION['role_level'];
$user_id = $_SESSION['user_id'];

// جلب عدد الرسائل غير المقروءة
$stmtMsg = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0");
$stmtMsg->execute([$user_id]);
$unread_messages = $stmtMsg->fetchColumn();

// جلب عدد الإحصائيات بانتظار الملء
$pending_stats_count = 0;
if ($role_level >= 3) {
    $stmtPending = $pdo->prepare("
        SELECT COUNT(DISTINCT sd.id) FROM stat_definitions sd
        LEFT JOIN stat_assignments sa ON sd.id = sa.stat_id
        WHERE sd.stat_type != 'file_exchange'
        AND (
            sd.creator_id = (SELECT parent_id FROM users WHERE id = ?) 
            OR sd.creator_id = 1
            OR (sd.target_type = 'specific_users' AND sa.user_id = ?)
        )
        AND sd.id NOT IN (
            SELECT stat_id FROM stat_submissions 
            WHERE user_id = ? AND status = 'completed'
        )
    ");
    $stmtPending->execute([$user_id, $user_id, $user_id]);
    $pending_stats_count = $stmtPending->fetchColumn();
}

$role_name = "";
switch($role_level) {
    case 1: $role_name = "مدير الجامعة"; break;
    case 2: $role_name = "مسؤول مركزي"; break;
    case 3: $role_name = "عميد / مدير"; break;
    case 4: $role_name = "رئيس قسم"; break;
    default: $role_name = "مستخدم"; break;
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar">
    <div class="sidebar-header">
        <img src="assets/logo_mila.png" alt="جامعة ميلة" style="width: 60px; margin-bottom: 10px;">
        <h3>جامعة ميلة</h3>
        <p style="font-size: 0.7rem; color: #38bdf8;">نظام الإحصائيات المطور</p>
    </div>
    
    <div class="user-profile">
        <div class="user-avatar">
            <i class="fas fa-user-shield fa-2x" style="color: #38bdf8;"></i>
        </div>
        <div class="user-info">
            <div class="user-name"><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'مستخدم'); ?></div>
            <div class="user-role"><?php echo $role_name; ?></div>
        </div>
    </div>
    
    <nav class="sidebar-nav">
        <a href="dashboard.php" class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
            <i class="fas fa-th-large"></i> <span>لوحة التحكم</span>
        </a>
        
        <div class="nav-group-title">التحليل والتقارير</div>
        
        <a href="analytics_dashboard.php" class="nav-link <?php echo $current_page == 'analytics_dashboard.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-line"></i> <span>لوحة التحليل العامة</span>
        </a>
        
        <a href="manage_stats.php" class="nav-link">
            <i class="fas fa-brain"></i> <span>مركز الذكاء الاصطناعي</span>
        </a>

        <a href="smart_search.php" class="nav-link <?php echo $current_page == 'smart_search.php' ? 'active' : ''; ?>">
            <i class="fas fa-search"></i> <span>البحث الشامل</span>
        </a>

        <?php if ($role_level <= 2): ?>
        <a href="smart_alerts.php" class="nav-link <?php echo $current_page == 'smart_alerts.php' ? 'active' : ''; ?>">
            <i class="fas fa-bell"></i> <span>التنبيهات الذكية</span>
        </a>
        <?php endif; ?>

        <a href="reports.php" class="nav-link <?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
            <i class="fas fa-file-contract"></i> <span>التقارير الثابتة</span>
        </a>
        <a href="manage_stats.php" class="nav-link">
            <i class="fas fa-magic"></i> <span>محرك التقارير المخصصة</span>
        </a>

        <div class="nav-group-title">الإحصائيات والبيانات</div>
        
        <a href="view_stats.php" class="nav-link <?php echo ($current_page == 'view_stats.php' && !isset($_GET['filter'])) ? 'active' : ''; ?>">
            <i class="fas fa-list-ul"></i> <span>كل النماذج</span>
        </a>

        <?php if ($role_level >= 3): ?>
        <a href="view_stats.php?filter=pending" class="nav-link <?php echo (isset($_GET['filter']) && $_GET['filter'] == 'pending') ? 'active' : ''; ?>">
            <i class="fas fa-clock"></i> <span>بانتظار الملء</span>
            <?php if($pending_stats_count > 0): ?>
                <span class="nav-badge warning"><?php echo $pending_stats_count; ?></span>
            <?php endif; ?>
        </a>
        <?php endif; ?>

        <a href="file_stats.php" class="nav-link <?php echo $current_page == 'file_stats.php' ? 'active' : ''; ?>">
            <i class="fas fa-folder-open"></i> <span>تبادل الملفات</span>
        </a>

        <div class="nav-group-title">الأرشفة والنظام</div>
        
        <a href="archive.php" class="nav-link <?php echo $current_page == 'archive.php' ? 'active' : ''; ?>">
            <i class="fas fa-archive"></i> <span>الأرشيف السنوي</span>
        </a>

        <?php if ($role_level == 1): ?>
        <a href="archive_system.php" class="nav-link <?php echo $current_page == 'archive_system.php' ? 'active' : ''; ?>">
            <i class="fas fa-server"></i> <span>إدارة الأرشفة</span>
        </a>
        <a href="audit_system.php" class="nav-link <?php echo $current_page == 'audit_system.php' ? 'active' : ''; ?>">
            <i class="fas fa-fingerprint"></i> <span>سجل الأنشطة</span>
        </a>
        <?php endif; ?>

        <a href="messages.php?folder=inbox" class="nav-link <?php echo ($current_page == 'messages.php') ? 'active' : ''; ?>">
            <i class="fas fa-envelope"></i> <span>المراسلات</span>
            <?php if($unread_messages > 0): ?>
                <span class="nav-badge"><?php echo $unread_messages; ?></span>
            <?php endif; ?>
        </a>

        <?php if ($role_level <= 3): ?>
        <div class="nav-group-title">إدارة النظام</div>
        <a href="manage_stats.php" class="nav-link <?php echo $current_page == 'manage_stats.php' ? 'active' : ''; ?>">
            <i class="fas fa-tasks"></i> <span>إدارة النماذج</span>
        </a>
        <a href="manage_users.php" class="nav-link <?php echo $current_page == 'manage_users.php' ? 'active' : ''; ?>">
            <i class="fas fa-users-cog"></i> <span>إدارة المستخدمين</span>
        </a>
        <?php endif; ?>
        
        <div class="sidebar-footer">
            <div class="nav-link" onclick="toggleDarkMode()" style="cursor: pointer;">
                <i class="fas fa-moon" id="theme-icon"></i> <span id="theme-text">الوضع الليلي</span>
            </div>
            <a href="logout.php" class="nav-link logout-link">
                <i class="fas fa-sign-out-alt"></i> <span>تسجيل الخروج</span>
            </a>
        </div>
    </nav>
</div>

<script>
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDark);
    updateThemeUI(isDark);
}

function updateThemeUI(isDark) {
    const icon = document.getElementById('theme-icon');
    const text = document.getElementById('theme-text');
    if (icon && text) {
        if (isDark) {
            icon.classList.replace('fa-moon', 'fa-sun');
            text.innerText = 'الوضع النهاري';
        } else {
            icon.classList.replace('fa-sun', 'fa-moon');
            text.innerText = 'الوضع الليلي';
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const savedMode = localStorage.getItem('darkMode') === 'true';
    if (savedMode) {
        document.body.classList.add('dark-mode');
        updateThemeUI(true);
    }
});
</script>

<style>
.sidebar { width: 260px; background: #0f172a; color: #f8fafc; height: 100vh; position: fixed; right: 0; top: 0; display: flex; flex-direction: column; box-shadow: -2px 0 15px rgba(0,0,0,0.2); z-index: 1000; transition: all 0.3s ease; }
.sidebar-header { padding: 30px 20px; text-align: center; background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(255,255,255,0.05); }
.sidebar-header h3 { margin-top: 10px; font-size: 1.1rem; color: #fff; letter-spacing: 0.5px; }
.user-profile { padding: 15px; display: flex; align-items: center; gap: 12px; background: rgba(255,255,255,0.05); margin: 15px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1); }
.user-name { font-weight: 600; font-size: 0.9rem; color: #fff; }
.user-role { font-size: 0.7rem; color: #94a3b8; }
.sidebar-nav { flex: 1; overflow-y: auto; padding: 10px 15px; }
.nav-group-title { font-size: 0.65rem; text-transform: uppercase; color: #475569; margin: 25px 10px 10px; letter-spacing: 1.5px; font-weight: 800; }
.nav-link { display: flex; align-items: center; padding: 10px 15px; color: #94a3b8; text-decoration: none; border-radius: 10px; margin-bottom: 4px; transition: all 0.2s; font-size: 0.9rem; }
.nav-link i { width: 20px; font-size: 1rem; margin-left: 12px; transition: transform 0.2s; }
.nav-link:hover { background: rgba(255,255,255,0.08); color: #fff; }
.nav-link.active { background: #2563eb; color: #fff; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3); }
.nav-badge { background: #ef4444; color: white; font-size: 0.65rem; padding: 2px 7px; border-radius: 20px; margin-right: auto; font-weight: bold; }
.nav-badge.warning { background: #f59e0b; }
.sidebar-footer { margin-top: auto; padding: 15px; border-top: 1px solid rgba(255,255,255,0.05); }
.logout-link:hover { background: #ef4444 !important; color: #fff !important; }
body { margin-right: 260px; background-color: #f8fafc; }
@media (max-width: 768px) {
    .sidebar { width: 80px; }
    .sidebar span, .sidebar .user-info, .sidebar .nav-group-title, .sidebar h3, .sidebar p { display: none; }
    body { margin-right: 80px; }
    .user-profile { padding: 10px; margin: 10px; justify-content: center; }
    .nav-link i { margin-left: 0; }
    .nav-link { justify-content: center; }
}
</style>
