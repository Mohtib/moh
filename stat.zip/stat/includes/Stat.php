<?php
class Stat {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->initAuditTable();
    }

    private function initAuditTable() {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS audit_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                action_type VARCHAR(50) NOT NULL,
                description TEXT NOT NULL,
                ip_address VARCHAR(45),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
            $this->pdo->exec($sql);
        } catch (PDOException $e) {
            error_log("Error creating audit_logs table: " . $e->getMessage());
        }
    }

    /**
     * التحقق من وجود جدول في قاعدة البيانات
     */
    public function tableExists($table_name) {
        try {
            $result = $this->pdo->query("SELECT 1 FROM `$table_name` LIMIT 1");
            return $result !== false;
        } catch (Exception $e) {
            return false;
        }
    }

    public function logAction($user_id, $type, $desc) {
        try {
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            $stmt = $this->pdo->prepare("INSERT INTO audit_logs (user_id, action_type, description, ip_address) VALUES (?, ?, ?, ?)");
            return $stmt->execute([$user_id, $type, $desc, $ip]);
        } catch (Exception $e) {
            error_log("Audit Log Error: " . $e->getMessage());
            return false;
        }
    }

    public function calculateQualityScore($data, $columns) {
        if (empty($data)) return 0;
        
        $totalFields = 0;
        $filledFields = 0;
        $numericValid = 0;
        $numericCount = 0;
        
        foreach ($data as $row) {
            foreach ($columns as $col) {
                $colName = $col['column_name'] ?? $col['name'];
                $totalFields++;
                if (isset($row[$colName]) && $row[$colName] !== '' && $row[$colName] !== null) {
                    $filledFields++;
                    $dataType = $col['data_type'] ?? $col['type'];
                    if (in_array($dataType, ['number', 'integer', 'decimal'])) {
                        $numericCount++;
                        if (is_numeric($row[$colName])) {
                            $numericValid++;
                        }
                    }
                }
            }
        }
        
        $completeness = ($totalFields > 0) ? ($filledFields / $totalFields) * 100 : 0;
        $numericAccuracy = ($numericCount > 0) ? ($numericValid / $numericCount) * 100 : 100;
        
        $score = ($completeness * 0.7) + ($numericAccuracy * 0.3);
        return round($score, 1);
    }

    public function addNotification($user_id, $message) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO notifications (user_id, message, is_read, created_at) VALUES (?, ?, 0, NOW())");
            return $stmt->execute([$user_id, $message]);
        } catch (PDOException $e) {
            error_log("Error adding notification: " . $e->getMessage());
            return false;
        }
    }

    public function getNotifications($user_id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
            $stmt->execute([$user_id]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            return [];
        }
    }

    public function markNotificationsRead($user_id) {
        try {
            $stmt = $this->pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
            return $stmt->execute([$user_id]);
        } catch (PDOException $e) {
            return false;
        }
    }

    public function createStatDefinition($creator_id, $name, $type, $columns, $parent_stat_id = null, $target_type = 'all_subordinates', $assigned_users = []) {
        try {
            if (!$this->pdo->inTransaction()) {
                $this->pdo->beginTransaction();
            }

            $table_name = "dynamic_stat_" . time() . "_" . rand(100, 999);
            
            $stmt = $this->pdo->prepare("INSERT INTO stat_definitions (creator_id, stat_name, stat_type, table_name, parent_stat_id, target_type) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$creator_id, $name, $type, $table_name, $parent_stat_id, $target_type]);
            $stat_id = $this->pdo->lastInsertId();

            if ($target_type == 'specific_users' && !empty($assigned_users)) {
                $stmtAssign = $this->pdo->prepare("INSERT INTO stat_assignments (stat_id, user_id) VALUES (?, ?)");
                foreach ($assigned_users as $user_id) {
                    $stmtAssign->execute([$stat_id, $user_id]);
                }
            }

            $sql = "CREATE TABLE `$table_name` (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                stat_year INT NOT NULL,
                stat_period INT NOT NULL,
                is_completed TINYINT(1) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,";

            foreach ($columns as $col) {
                $safe_col_name = preg_replace('/[^a-zA-Z0-9_]/', '', $col['name']);
                
                $stmtCol = $this->pdo->prepare("INSERT INTO stat_columns (stat_id, column_name, column_label, data_type) VALUES (?, ?, ?, ?)");
                $stmtCol->execute([$stat_id, $safe_col_name, $col['label'], $col['type']]);
                
                $sqlType = "VARCHAR(255)";
                switch ($col['type']) {
                    case 'number':
                    case 'decimal': $sqlType = "DECIMAL(15,2)"; break;
                    case 'integer': $sqlType = "INT"; break;
                    case 'text': $sqlType = "TEXT"; break;
                    case 'boolean': $sqlType = "TINYINT(1)"; break;
                    case 'date': $sqlType = "DATE"; break;
                    case 'file':
                    case 'image': $sqlType = "VARCHAR(255)"; break;
                }
                
                $sql .= "`$safe_col_name` $sqlType,";
            }
            
            $sql .= "FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
            $this->pdo->exec($sql);

            $target_users = [];
            if ($target_type == 'specific_users') {
                $target_users = $assigned_users;
            } else {
                $stmtUsers = $this->pdo->prepare("SELECT id FROM users WHERE parent_id = ?");
                $stmtUsers->execute([$creator_id]);
                $target_users = $stmtUsers->fetchAll(PDO::FETCH_COLUMN);
            }

            foreach ($target_users as $sub_id) {
                if ($sub_id == $creator_id) continue; 
                $this->addNotification($sub_id, "تم إنشاء إحصائية جديدة: $name. يرجى التعبئة.");
                $stmtSub = $this->pdo->prepare("INSERT IGNORE INTO stat_submissions (stat_id, user_id, status) VALUES (?, ?, 'pending')");
                $stmtSub->execute([$stat_id, $sub_id]);
            }

            $this->logAction($creator_id, 'CREATE', "تم إنشاء إحصائية جديدة: $name");
            $this->pdo->commit();
            return true;
        } catch (Exception $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            error_log("Error in createStatDefinition: " . $e->getMessage());
            return false;
        }
    }

    public function getAvailableStats($user_id, $role_level) {
        try {
            if ($role_level == 1) {
                $stmt = $this->pdo->prepare("SELECT sd.*, u.full_name as creator_name FROM stat_definitions sd JOIN users u ON sd.creator_id = u.id ORDER BY sd.created_at DESC");
                $stmt->execute();
            } else {
                $sub_ids = $this->getAllSubordinateIds($user_id);
                $placeholders = implode(',', array_fill(0, count($sub_ids), '?'));
                
                $stmt = $this->pdo->prepare("
                    SELECT DISTINCT sd.*, u.full_name as creator_name 
                    FROM stat_definitions sd 
                    JOIN users u ON sd.creator_id = u.id 
                    LEFT JOIN stat_assignments sa ON sd.id = sa.stat_id 
                    WHERE sd.creator_id IN ($placeholders) 
                       OR (sd.target_type = 'all_subordinates' AND sd.creator_id = (SELECT parent_id FROM users WHERE id = ?)) 
                       OR (sd.target_type = 'specific_users' AND sa.user_id = ?) 
                       OR sd.creator_id = 1 
                    ORDER BY sd.created_at DESC
                ");
                $params = array_merge($sub_ids, [$user_id, $user_id]);
                $stmt->execute($params);
            }
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            return [];
        }
    }

    public function getStatDetails($stat_id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM stat_definitions WHERE id = ?");
            $stmt->execute([$stat_id]);
            $stat = $stmt->fetch();
            if ($stat) {
                $stmtCols = $this->pdo->prepare("SELECT * FROM stat_columns WHERE stat_id = ?");
                $stmtCols->execute([$stat_id]);
                $stat['columns'] = $stmtCols->fetchAll();
            }
            return $stat;
        } catch (PDOException $e) {
            return null;
        }
    }

    public function checkDataExists($table_name, $user_id, $year, $period) {
        if (!$this->tableExists($table_name)) return false;
        try {
            $stmt = $this->pdo->prepare("SELECT id, is_completed FROM `$table_name` WHERE user_id = ? AND stat_year = ? AND stat_period = ?");
            $stmt->execute([$user_id, $year, $period]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function updateData($table_name, $id, $data) {
        if (!$this->tableExists($table_name)) return false;
        try {
            $stmtCols = $this->pdo->query("DESCRIBE `$table_name` ");
            $existingCols = $stmtCols->fetchAll(PDO::FETCH_COLUMN);
            $sets = []; $params = [];
            foreach ($data as $key => $value) {
                if (in_array($key, $existingCols)) {
                    $sets[] = "`$key` = ?";
                    $params[] = $value;
                }
            }
            if (empty($sets)) return true;
            $params[] = $id;
            $sql = "UPDATE `$table_name` SET " . implode(", ", $sets) . " WHERE id = ?";
            $res = $this->pdo->prepare($sql)->execute($params);
            if ($res) $this->logAction($data['user_id'] ?? 0, 'UPDATE', "قام بتحديث بيانات في جدول: $table_name (ID: $id)");
            return $res;
        } catch (PDOException $e) {
            error_log("Error in updateData: " . $e->getMessage());
            return false;
        }
    }

    public function saveData($table_name, $data) {
        if (!$this->tableExists($table_name)) return false;
        try {
            $stmtCols = $this->pdo->query("DESCRIBE `$table_name` ");
            $existingCols = $stmtCols->fetchAll(PDO::FETCH_COLUMN);
            $filteredData = [];
            foreach ($data as $key => $value) {
                if (in_array($key, $existingCols)) $filteredData[$key] = $value;
            }
            if (empty($filteredData)) return false;
            $columns = array_keys($filteredData);
            $placeholders = array_fill(0, count($columns), "?");
            $sql = "INSERT INTO `$table_name` (" . implode(", ", array_map(function($c){ return "`$c`"; }, $columns)) . ") VALUES (" . implode(", ", $placeholders) . ")";
            $res = $this->pdo->prepare($sql)->execute(array_values($filteredData));
            if ($res) $this->logAction($data['user_id'] ?? 0, 'CREATE', "قام بإضافة بيانات جديدة في جدول: $table_name");
            return $res;
        } catch (PDOException $e) {
            error_log("Error in saveData: " . $e->getMessage());
            return false;
        }
    }

    public function getStatData($table_name, $user_id = null, $role_level = 4, $filters = []) {
        if (!$this->tableExists($table_name)) return [];
        try {
            $sql = "SELECT t.*, u.full_name FROM `$table_name` t JOIN users u ON t.user_id = u.id";
            $params = []; $where = [];
            
            if ($role_level != 1 && $user_id) {
                $all_ids = $this->getAllSubordinateIds($user_id);
                if (!empty($all_ids)) {
                    $placeholders = implode(',', array_fill(0, count($all_ids), '?'));
                    $where[] = "t.user_id IN ($placeholders)";
                    $params = array_merge($params, $all_ids);
                } else {
                    $where[] = "t.user_id = ?";
                    $params[] = $user_id;
                }
            }
            
            if (!empty($filters['user_id'])) {
                $where[] = "t.user_id = ?";
                $params[] = $filters['user_id'];
            }
            if (!empty($filters['year'])) {
                $where[] = "t.stat_year = ?";
                $params[] = $filters['year'];
            }
            if (!empty($where)) $sql .= " WHERE " . implode(" AND ", $where);
            $sql .= " ORDER BY t.stat_year DESC, t.stat_period DESC";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error in getStatData: " . $e->getMessage());
            return [];
        }
    }

    public function getAllSubordinateIds($parent_id) {
        try {
            $ids = [$parent_id];
            $stmt = $this->pdo->prepare("SELECT id FROM users WHERE parent_id = ?");
            $stmt->execute([$parent_id]);
            $children = $stmt->fetchAll(PDO::FETCH_COLUMN);
            foreach ($children as $child_id) {
                $ids = array_merge($ids, $this->getAllSubordinateIds($child_id));
            }
            return array_unique($ids);
        } catch (PDOException $e) {
            return [$parent_id];
        }
    }

    public function calculateStats($data, $columns) {
        $totals = []; $averages = []; $growth = []; $percentages = [];
        $count = count($data);
        if ($count === 0) return ['totals' => [], 'averages' => [], 'growth' => [], 'percentages' => [], 'yearly_data' => []];

        foreach ($columns as $col) {
            $col_name = $col['column_name'] ?? $col['name'];
            $col_type = $col['data_type'] ?? $col['type'];
            if (in_array($col_type, ['number', 'integer', 'decimal'])) {
                $sum = 0;
                foreach ($data as $row) $sum += (float)($row[$col_name] ?? 0);
                $totals[$col_name] = $sum;
                $averages[$col_name] = $sum / $count;
            }
        }

        foreach ($data as $row) {
            foreach ($columns as $col) {
                $col_name = $col['column_name'] ?? $col['name'];
                if (isset($totals[$col_name]) && $totals[$col_name] > 0) {
                    $percentages[$row['id']][$col_name] = ((float)($row[$col_name] ?? 0) / $totals[$col_name]) * 100;
                }
            }
        }

        $yearly_data = [];
        foreach ($data as $row) {
            $year = $row['stat_year'];
            foreach ($columns as $col) {
                $col_name = $col['column_name'] ?? $col['name'];
                $col_type = $col['data_type'] ?? $col['type'];
                if (in_array($col_type, ['number', 'integer', 'decimal'])) {
                    $yearly_data[$year][$col_name] = ($yearly_data[$year][$col_name] ?? 0) + (float)($row[$col_name] ?? 0);
                }
            }
        }
        
        $years = array_keys($yearly_data);
        rsort($years);
        if (count($years) >= 2) {
            $curr = $years[0]; $prev = $years[1];
            foreach ($columns as $col) {
                $col_name = $col['column_name'] ?? $col['name'];
                if (isset($yearly_data[$curr][$col_name]) && isset($yearly_data[$prev][$col_name]) && $yearly_data[$prev][$col_name] != 0) {
                    $growth[$col_name] = (($yearly_data[$curr][$col_name] - $yearly_data[$prev][$col_name]) / $yearly_data[$prev][$col_name]) * 100;
                }
            }
        }

        return ['totals' => $totals, 'averages' => $averages, 'growth' => $growth, 'percentages' => $percentages, 'yearly_data' => $yearly_data];
    }

    private function predictFutureValue($years, $values) {
        $n = count($years);
        if ($n < 2) return null;
        $sumX = array_sum($years);
        $sumY = array_sum($values);
        $sumXY = 0; $sumX2 = 0;
        for ($i = 0; $i < $n; $i++) {
            $sumXY += ($years[$i] * $values[$i]);
            $sumX2 += ($years[$i] * $years[$i]);
        }
        $denominator = ($n * $sumX2) - ($sumX * $sumX);
        if ($denominator == 0) return null;
        $slope = ($n * $sumXY - $sumX * $sumY) / $denominator;
        $intercept = ($sumY - $slope * $sumX) / $n;
        $nextYear = max($years) + 1;
        return ($slope * $nextYear) + $intercept;
    }

    public function calculateCorrelation($data, $col1, $col2) {
        $x = array_column($data, $col1);
        $y = array_column($data, $col2);
        $n = count($x);
        if ($n < 2) return 0;
        $avgX = array_sum($x) / $n;
        $avgY = array_sum($y) / $n;
        $num = 0; $den1 = 0; $den2 = 0;
        for ($i = 0; $i < $n; $i++) {
            $diffX = $x[$i] - $avgX;
            $diffY = $y[$i] - $avgY;
            $num += ($diffX * $diffY);
            $den1 += pow($diffX, 2);
            $den2 += pow($diffY, 2);
        }
        $den = sqrt($den1 * $den2);
        return ($den == 0) ? 0 : $num / $den;
    }

    public function analyzeWithAI($data, $stat_name, $columns) {
        if (empty($data)) return "لا توجد بيانات كافية للتحليل حالياً.";
        
        $count = count($data);
        $analysis = "### 🤖 تقرير الذكاء الاصطناعي الفائق: $stat_name\n\n";
        $analysis .= "> تم تحليل **$count** سجل بيانات باستخدام محرك الذكاء الاصطناعي الإحصائي.\n\n";

        $calc = $this->calculateStats($data, $columns);
        
        if (!empty($calc['growth'])) {
            $analysis .= "#### 📈 تحليل الاتجاهات (Trend Analysis)\n";
            foreach ($calc['growth'] as $col_name => $rate) {
                $label = "";
                foreach($columns as $c) if(($c['column_name'] ?? $c['name']) == $col_name) $label = $c['column_label'] ?? $c['label'];
                $direction = $rate > 0 ? "ارتفاعاً 🟢" : "انخفاضاً 🔴";
                $analysis .= "- سجل مؤشر **($label)** $direction بنسبة **" . abs(round($rate, 2)) . "%** مقارنة بالدورة السابقة.\n";
            }
            $analysis .= "\n";
        }

        $anomalies = [];
        foreach ($columns as $col) {
            $col_name = $col['column_name'] ?? $col['name'];
            if (isset($calc['averages'][$col_name])) {
                $avg = $calc['averages'][$col_name];
                foreach ($data as $row) {
                    $val = (float)($row[$col_name] ?? 0);
                    if ($avg > 0 && ($val > $avg * 2.5 || $val < $avg / 4) && $val != 0) {
                        $anomalies[] = "قيمة استثنائية (**$val**) في حقل ({$col['column_label']}) للجهة (**{$row['full_name']}**)";
                    }
                }
            }
        }
        
        if (!empty($anomalies)) {
            $analysis .= "#### ⚠️ تنبيهات القيم الشاذة (Anomaly Detection)\n";
            foreach (array_slice($anomalies, 0, 4) as $a) $analysis .= "- $a\n";
            $analysis .= "\n";
        }

        $years_list = array_keys($calc['yearly_data']);
        sort($years_list);
        if (count($years_list) >= 2) {
            $analysis .= "#### 🔮 التنبؤات المستقبلية (Predictive Insights)\n";
            foreach ($columns as $col) {
                $col_name = $col['column_name'] ?? $col['name'];
                if (in_array($col['data_type'] ?? '', ['number', 'integer', 'decimal'])) {
                    $values_list = [];
                    foreach($years_list as $y) $values_list[] = (float)($calc['yearly_data'][$y][$col_name] ?? 0);
                    $prediction = $this->predictFutureValue($years_list, $values_list);
                    if ($prediction !== null) {
                        $label = $col['column_label'] ?? $col['label'];
                        $analysis .= "- المتوقع لـ **($label)** في العام القادم: **" . number_format($prediction, 2) . "** (بثقة إحصائية عالية).\n";
                    }
                }
            }
            $analysis .= "\n";
        }

        $numeric_cols = [];
        foreach($columns as $c) if(in_array($c['data_type'] ?? '', ['number', 'integer', 'decimal'])) $numeric_cols[] = $c;
        if (count($numeric_cols) >= 2) {
            $analysis .= "#### 🔗 مصفوفة الارتباطات (Correlation Matrix)\n";
            for ($i = 0; $i < min(3, count($numeric_cols)); $i++) {
                for ($j = $i + 1; $j < min(3, count($numeric_cols)); $j++) {
                    $c1 = $numeric_cols[$i]; $c2 = $numeric_cols[$j];
                    $corr = $this->calculateCorrelation($data, $c1['column_name'], $c2['column_name']);
                    if (abs($corr) > 0.6) {
                        $strength = $corr > 0 ? "طردي" : "عكسي";
                        $analysis .= "- يوجد ارتباط **$strength** ملحوظ بين ({$c1['column_label']}) و ({$c2['column_label']}) بمقدار (**" . round($corr, 2) . "**).\n";
                    }
                }
            }
        }

        return $analysis;
    }

    public function deleteStat($stat_id, $user_id, $role_level) {
        try {
            $stat = $this->getStatDetails($stat_id);
            if (!$stat) return false;

            if ($role_level != 1) {
                if ($stat['creator_id'] != $user_id) {
                    $subordinate_ids = $this->getAllSubordinateIds($user_id);
                    if (!in_array($stat['creator_id'], $subordinate_ids)) return false;
                }
            }

            $this->pdo->beginTransaction();
            $this->pdo->prepare("DELETE FROM stat_columns WHERE stat_id = ?")->execute([$stat_id]);
            $this->pdo->prepare("DELETE FROM stat_assignments WHERE stat_id = ?")->execute([$stat_id]);
            $this->pdo->prepare("DELETE FROM stat_submissions WHERE stat_id = ?")->execute([$stat_id]);
            if ($this->tableExists($stat['table_name'])) {
                $this->pdo->prepare("DROP TABLE IF EXISTS `{$stat['table_name']}`")->execute();
            }
            $this->pdo->prepare("DELETE FROM stat_definitions WHERE id = ?")->execute([$stat_id]);
            $this->logAction($user_id, 'DELETE', "تم حذف الإحصائية: {$stat['stat_name']}");
            $this->pdo->commit();
            return true;
        } catch (Exception $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            return false;
        }
    }
}
?>
