<?php
session_start();
require_once '../config/db.php';
require_once '../includes/User.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role_level'] != 1) {
    die(json_encode(['success' => false, 'message' => 'غير مصرح']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userObj = new User($pdo);
    $result = $userObj->addUser(
        $_POST['username'],
        $_POST['password'],
        $_POST['full_name'],
        $_POST['role_level'],
        $_POST['parent_id']
    );
    echo json_encode(['success' => $result]);
}
?>