<?php
session_start();
require_once '../config/db.php';
require_once '../includes/Stat.php';
require_once '../includes/User.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    die(json_encode(['success' => false, 'message' => 'غير مصرح']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $statObj = new Stat($pdo);
    
    // التحقق من المدخلات الأساسية
    $stat_name = filter_input(INPUT_POST, 'stat_name', FILTER_SANITIZE_SPECIAL_CHARS);
    $stat_type = filter_input(INPUT_POST, 'stat_type', FILTER_SANITIZE_SPECIAL_CHARS);
    $parent_stat_id = !empty($_POST['parent_stat_id']) ? (int)$_POST['parent_stat_id'] : null;
    $target_type = $_POST['target_type'] ?? 'all_subordinates';
    $assigned_users = isset($_POST['assigned_users']) && is_array($_POST['assigned_users']) ? array_map('intval', $_POST['assigned_users']) : [];
    $edit_id = !empty($_POST['edit_id']) ? (int)$_POST['edit_id'] : null;

    if (empty($stat_name)) {
        die(json_encode(['success' => false, 'message' => 'اسم الإحصائية مطلوب']));
    }

    // إجبارية اختيار المستخدمين إذا كان النوع محدد
    if ($target_type === 'specific_users' && empty($assigned_users)) {
        die(json_encode(['success' => false, 'message' => 'يرجى اختيار مستخدم واحد على الأقل عند تحديد مستخدمين معينين']));
    }

    // التحقق من أن المستخدمين المحددين هم تابعون فعلياً للمستخدم الحالي (إلا إذا كان مديراً)
    $valid_users = [];
    if ($target_type === 'specific_users' && !empty($assigned_users)) {
        if ($_SESSION['role_level'] == 1) {
            $valid_users = $assigned_users; // المدير يمكنه تعيين أي مستخدم
        } else {
            $userObj = new User($pdo);
            $subordinates = $userObj->getSubordinates($_SESSION['user_id'], false);
            $sub_ids = array_column($subordinates, 'id');
            $valid_users = array_intersect($assigned_users, $sub_ids);
            if (empty($valid_users)) {
                die(json_encode(['success' => false, 'message' => 'المستخدمون المحددون غير تابعين لك']));
            }
        }
    }

    if ($edit_id) {
        // التحقق من ملكية الإحصائية
        $stmtCheck = $pdo->prepare("SELECT creator_id FROM stat_definitions WHERE id = ?");
        $stmtCheck->execute([$edit_id]);
        $creator = $stmtCheck->fetchColumn();
        if (!$creator || ($creator != $_SESSION['user_id'] && $_SESSION['role_level'] != 1)) {
            die(json_encode(['success' => false, 'message' => 'غير مصرح بتعديل هذه الإحصائية']));
        }
        
        try {
            $pdo->beginTransaction();
            
            // تحديث التعريف الرئيسي
            $stmt = $pdo->prepare("UPDATE stat_definitions SET stat_name = ?, stat_type = ?, parent_stat_id = ?, target_type = ? WHERE id = ?");
            $stmt->execute([$stat_name, $stat_type, $parent_stat_id, $target_type, $edit_id]);
            
            // تحديث تسميات الأعمدة
            if (isset($_POST['col_name']) && is_array($_POST['col_name'])) {
                $labels = $_POST['col_label'] ?? [];
                $names = $_POST['col_name'];
                $types = $_POST['col_type'] ?? [];
                
                for ($i = 0; $i < count($names); $i++) {
                    $label = filter_var($labels[$i] ?? '', FILTER_SANITIZE_SPECIAL_CHARS);
                    $type = filter_var($types[$i] ?? 'string', FILTER_SANITIZE_SPECIAL_CHARS);
                    $name = filter_var($names[$i], FILTER_SANITIZE_SPECIAL_CHARS);
                    
                    $stmtCol = $pdo->prepare("UPDATE stat_columns SET column_label = ?, data_type = ? WHERE stat_id = ? AND column_name = ?");
                    $stmtCol->execute([$label, $type, $edit_id, $name]);
                }
            }
            
            // تحديث التوجيهات
            $stmtDel = $pdo->prepare("DELETE FROM stat_assignments WHERE stat_id = ?");
            $stmtDel->execute([$edit_id]);
            
            if ($target_type == 'specific_users' && !empty($valid_users)) {
                $stmtAssign = $pdo->prepare("INSERT INTO stat_assignments (stat_id, user_id) VALUES (?, ?)");
                foreach ($valid_users as $user_id) {
                    $stmtAssign->execute([$edit_id, $user_id]);
                }
            }
            
            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'تم تحديث الإحصائية بنجاح']);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            echo json_encode(['success' => false, 'message' => 'خطأ أثناء التحديث: ' . $e->getMessage()]);
        }
    } else {
        // إنشاء جديد
        $columns = [];
        if (!isset($_POST['col_name']) || !is_array($_POST['col_name']) || empty($_POST['col_name'])) {
            die(json_encode(['success' => false, 'message' => 'يجب إضافة عمود واحد على الأقل']));
        }

        $labels = $_POST['col_label'] ?? [];
        $names = $_POST['col_name'];
        $types = $_POST['col_type'] ?? [];
        
        for ($i = 0; $i < count($names); $i++) {
            $col_name = preg_replace('/[^a-zA-Z0-9_]/', '', $names[$i]);
            if (empty($col_name)) continue;
            
            $columns[] = [
                'label' => filter_var($labels[$i] ?? '', FILTER_SANITIZE_SPECIAL_CHARS),
                'name' => $col_name,
                'type' => filter_var($types[$i] ?? 'string', FILTER_SANITIZE_SPECIAL_CHARS)
            ];
        }

        if (empty($columns)) {
            die(json_encode(['success' => false, 'message' => 'بيانات الأعمدة غير صالحة']));
        }

        $result = $statObj->createStatDefinition(
            $_SESSION['user_id'],
            $stat_name,
            $stat_type,
            $columns,
            $parent_stat_id,
            $target_type,
            $valid_users // استخدام المستخدمين الذين تم التحقق منهم
        );
        
        if ($result) {
            echo json_encode(['success' => true, 'message' => 'تم إنشاء الإحصائية بنجاح وإخطار التابعين']);
        } else {
            echo json_encode(['success' => false, 'message' => 'حدث خطأ أثناء إنشاء الإحصائية. تأكد من صحة البيانات والمحاولة مرة أخرى.']);
        }
    }
} else {
    echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صالحة']);
}
?>