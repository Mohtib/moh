<?php
session_start();
require_once '../config/db.php';
require_once '../includes/Stat.php';
require_once '../includes/User.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$action = $_GET['action'] ?? '';
$statObj = new Stat($pdo);
$userObj = new User($pdo);
$current_user_id = $_SESSION['user_id'];
$role_level = (int)$_SESSION['role_level'];

/**
 * الحصول على جميع المعرفات التابعة لمستخدم معين (بشكل متكرر)
 */
function getAllSubordinateIds($pdo, $parent_id) {
    $ids = [$parent_id];
    $stmt = $pdo->prepare("SELECT id FROM users WHERE parent_id = ?");
    $stmt->execute([$parent_id]);
    $children = $stmt->fetchAll(PDO::FETCH_COLUMN);
    foreach ($children as $child_id) {
        $ids = array_merge($ids, getAllSubordinateIds($pdo, $child_id));
    }
    return $ids;
}

// 1. جلب الإحصائيات الأب (التي ليس لها أب)
if ($action == 'get_root_stats') {
    $stmt = $pdo->query("SELECT id, stat_name FROM stat_definitions WHERE parent_stat_id IS NULL");
    echo json_encode($stmt->fetchAll());
}

// 2. جلب الإحصائيات الأبناء لإحصائية معينة
elseif ($action == 'get_child_stats') {
    $parent_id = $_GET['parent_id'] ?? null;
    $stmt = $pdo->prepare("SELECT id, stat_name FROM stat_definitions WHERE parent_stat_id = ?");
    $stmt->execute([$parent_id]);
    echo json_encode($stmt->fetchAll());
}

// 3. جلب المستخدمين التابعين (هرمياً)
elseif ($action == 'get_subordinates') {
    $parent_id = $_GET['parent_id'] ?? null;
    // إذا كان المستخدم الحالي ليس مديراً، نتحقق من أن parent_id هو نفسه أو أحد تابعيه
    if ($role_level != 1 && $parent_id != $current_user_id) {
        $all_sub_ids = getAllSubordinateIds($pdo, $current_user_id);
        if (!in_array($parent_id, $all_sub_ids)) {
            echo json_encode([]);
            exit();
        }
    }
    $subs = $userObj->getSubordinates($parent_id, false);
    echo json_encode($subs);
}

// 4. جلب البيانات الإحصائية مع التحليل المتقدم
elseif ($action == 'get_stat_data_advanced') {
    $stat_id = $_GET['stat_id'] ?? null;
    $user_id_filter = $_GET['user_id'] ?? 'all';
    
    if (!$stat_id) {
        echo json_encode(['error' => 'Missing stat_id']);
        exit();
    }
    
    $stat = $statObj->getStatDetails($stat_id);
    if (!$stat) {
        echo json_encode(['error' => 'Stat not found']);
        exit();
    }

    $filters = [];
    // تحديد المستخدم المستهدف
    $target_user_id = ($user_id_filter !== 'all') ? (int)$user_id_filter : $current_user_id;
    
    // التحقق من الصلاحية: إذا لم يكن المستخدم مديراً، يجب أن يكون المستهدف هو نفسه أو أحد تابعيه
    if ($role_level != 1 && $target_user_id != $current_user_id) {
        $all_sub_ids = getAllSubordinateIds($pdo, $current_user_id);
        if (!in_array($target_user_id, $all_sub_ids)) {
            $target_user_id = $current_user_id; // إعادة تعيين للمستخدم الحالي
        }
    }

    // إذا كان user_id_filter = 'all'، نمرر null للدالة للحصول على الكل (حسب صلاحيات المستخدم)
    $data = $statObj->getStatData($stat['table_name'], $target_user_id, $role_level, $filters);
    $analysis = $statObj->calculateStats($data, $stat['columns']);
    
    echo json_encode([
        'stat' => $stat,
        'data' => $data,
        'analysis' => $analysis
    ]);
}

// 5. البحث الذكي في الإحصائيات
elseif ($action == 'ai_search') {
    $query = $_GET['query'] ?? '';
    $stats = $statObj->getAvailableStats($current_user_id, $role_level);
    $results = array_filter($stats, function($s) use ($query) {
        return mb_stripos($s['stat_name'], $query) !== false;
    });
    echo json_encode(array_values($results));
}

// 6. الفلترة المخصصة لمحرك التقارير الديناميكي
elseif ($action == 'custom_report_filter') {
    $stat_id = $_GET['stat_id'] ?? null;
    $cols = $_GET['cols'] ?? [];
    $year = $_GET['year'] ?? null;
    $user_id = $_GET['user_id'] ?? null;

    if (!$stat_id) {
        echo json_encode(['error' => 'Missing stat_id']);
        exit();
    }

    $stat = $statObj->getStatDetails($stat_id);
    if (!$stat) {
        echo json_encode(['error' => 'Stat not found']);
        exit();
    }

    // التحقق من أن المستخدم لديه صلاحية على هذه الإحصائية
    $available_stats = $statObj->getAvailableStats($current_user_id, $role_level);
    $is_allowed = false;
    foreach ($available_stats as $s) {
        if ($s['id'] == $stat_id) {
            $is_allowed = true;
            break;
        }
    }
    if (!$is_allowed) {
        echo json_encode(['error' => 'Unauthorized']);
        exit();
    }

    // بناء شروط WHERE
    $where = ["1=1"];
    $params = [];

    if ($year) {
        $where[] = "d.stat_year = ?";
        $params[] = $year;
    }
    if ($user_id) {
        // التحقق من أن المستخدم المطلوب مسموح به
        if ($role_level != 1) {
            $all_sub_ids = getAllSubordinateIds($pdo, $current_user_id);
            if (!in_array($user_id, $all_sub_ids)) {
                $user_id = $current_user_id;
            }
        }
        $where[] = "d.user_id = ?";
        $params[] = $user_id;
    } else {
        // إذا لم يتم تحديد مستخدم، نقتصر على المستخدم الحالي وتابعيه (إلا إذا كان مديراً)
        if ($role_level != 1) {
            $all_sub_ids = getAllSubordinateIds($pdo, $current_user_id);
            $placeholders = implode(',', array_fill(0, count($all_sub_ids), '?'));
            $where[] = "d.user_id IN ($placeholders)";
            $params = array_merge($params, $all_sub_ids);
        }
    }

    // تحديد الأعمدة المطلوبة
    $col_list = "u.full_name, d.stat_year, d.stat_period";
    if (!empty($cols)) {
        $valid_cols = array_column($stat['columns'], 'column_name');
        foreach ($cols as $c) {
            if (in_array($c, $valid_cols)) {
                $col_list .= ", d.`$c`";
            }
        }
    } else {
        $col_list .= ", d.*";
    }

    $sql = "SELECT $col_list FROM `{$stat['table_name']}` d JOIN users u ON d.user_id = u.id WHERE " . implode(" AND ", $where) . " ORDER BY d.stat_year DESC, d.stat_period DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    echo json_encode($stmt->fetchAll());
}

// إجراء غير معروف
else {
    echo json_encode(['error' => 'Invalid action']);
}
?>