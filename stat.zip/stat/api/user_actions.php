<?php
session_start();
require_once '../config/db.php';
require_once '../includes/User.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مصرح']);
    exit();
}

$userObj = new User($pdo);
$action = $_POST['action'] ?? '';

switch ($action) {
    case 'update':
        $id = $_POST['id'];
        $username = $_POST['username'];
        $full_name = $_POST['full_name'];
        
        // التحقق من الصلاحية (يجب أن يكون المدير أو الأب)
        $targetUser = $userObj->getUserById($id);
        if ($_SESSION['role_level'] == 1 || $targetUser['parent_id'] == $_SESSION['user_id']) {
            if ($userObj->updateUser($id, $username, $full_name)) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'فشل التحديث']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'ليس لديك صلاحية']);
        }
        break;

    case 'reset_password':
        $id = $_POST['id'];
        $new_password = $_POST['password'];
        
        $targetUser = $userObj->getUserById($id);
        if ($_SESSION['role_level'] == 1 || $targetUser['parent_id'] == $_SESSION['user_id']) {
            if ($userObj->resetPassword($id, $new_password)) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'فشل إعادة التعيين']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'ليس لديك صلاحية']);
        }
        break;

    case 'delete':
        $id = $_POST['id'];
        
        $targetUser = $userObj->getUserById($id);
        if ($_SESSION['role_level'] == 1 || $targetUser['parent_id'] == $_SESSION['user_id']) {
            if ($userObj->deleteUser($id)) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'فشل الحذف (قد يكون للمستخدم تابعين)']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'ليس لديك صلاحية']);
        }
        break;

    case 'mark_notifications_read':
        require_once '../includes/Stat.php';
        $statObj = new Stat($pdo);
        if ($statObj->markNotificationsRead($_SESSION['user_id'])) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'إجراء غير معروف']);
}
?>
